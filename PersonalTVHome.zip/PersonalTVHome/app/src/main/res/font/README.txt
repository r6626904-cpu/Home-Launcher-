Add Inter fonts here: inter_regular.ttf, inter_medium.ttf, inter_semibold.ttf (https://rsms.me/inter/)
