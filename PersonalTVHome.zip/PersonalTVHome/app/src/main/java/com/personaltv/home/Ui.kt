package com.personaltv.home

import android.os.Build
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.tv.material3.Icon
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Text
import androidx.tv.material3.darkColorScheme
import kotlin.math.sin

// ───────── Typography ─────────
val Inter = FontFamily(
    Font(R.font.inter_regular, FontWeight.Normal),
    Font(R.font.inter_medium, FontWeight.Medium),
    Font(R.font.inter_semibold, FontWeight.SemiBold)
)
val SoftWhite = Color(0xFFF3F5F9)
private val textShadow = Shadow(Color.Black.copy(.35f), Offset(0f, 2f), 14f)

object T {
    val display = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Medium, fontSize = 34.sp, letterSpacing = (-0.5).sp, color = SoftWhite, shadow = textShadow)
    val clock = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Medium, fontSize = 34.sp, fontFeatureSettings = "tnum", color = SoftWhite, shadow = textShadow)
    val weather = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Medium, fontSize = 28.sp, fontFeatureSettings = "tnum", color = SoftWhite, shadow = textShadow)
    val title = TextStyle(fontFamily = Inter, fontWeight = FontWeight.SemiBold, fontSize = 22.sp, color = SoftWhite)
    val body = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Normal, fontSize = 18.sp, color = SoftWhite.copy(.72f))
    val label = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Medium, fontSize = 17.sp, color = SoftWhite)
}

@Composable
fun PersonalTvTheme(content: @Composable () -> Unit) =
    MaterialTheme(colorScheme = darkColorScheme(primary = SoftWhite, onSurface = SoftWhite)) { content() }

// ───────── Backdrop: scenery, or the blurred album art ─────────
sealed interface Backdrop {
    data class Scene(val index: Int) : Backdrop
    data class Art(val soft: ImageBitmap) : Backdrop
}
val LocalBackdrop = compositionLocalOf<Backdrop> { Backdrop.Scene(0) }
val SceneNames = listOf("Alpine Dusk", "Coast Dawn", "Desert Haze")

private class SceneSpec(val sky: List<Color>, val ridges: List<Color>, val sun: Color)
private val scenes = listOf(
    SceneSpec(listOf(0xFF1B2A49, 0xFF6B6FA3, 0xFFF0A98B).map(::Color), listOf(0xFF4A5885, 0xFF2D3860, 0xFF1A2240).map(::Color), Color(0xFFFFE2C2)),
    SceneSpec(listOf(0xFF2C5A7A, 0xFF7FB2C4, 0xFFF6D9B0).map(::Color), listOf(0xFF5B8FA3, 0xFF356A80, 0xFF1F4558).map(::Color), Color(0xFFFFF1D6)),
    SceneSpec(listOf(0xFF3A2748, 0xFFB5586B, 0xFFF6B37A).map(::Color), listOf(0xFF8A4563, 0xFF5C3355, 0xFF33203F).map(::Color), Color(0xFFFFD9A8))
)

/** Procedural scenery. To use real photography, swap this for an Image(painterResource(R.drawable.x)). */
@Composable
fun SceneCanvas(index: Int, modifier: Modifier = Modifier) {
    val s = scenes[index.coerceIn(0, scenes.lastIndex)]
    Canvas(modifier) {
        drawRect(Brush.verticalGradient(s.sky))
        drawCircle(Brush.radialGradient(listOf(s.sun.copy(.9f), s.sun.copy(.0f)), Offset(size.width * .7f, size.height * .5f), size.height * .45f),
            size.height * .45f, Offset(size.width * .7f, size.height * .5f))
        s.ridges.forEachIndexed { i, c ->
            val p = Path().apply {
                moveTo(0f, size.height)
                var x = 0f
                while (x <= size.width) {
                    val f = 0.0016f + i * .0007f; val ph = i * 1.9f
                    val y = size.height * (.50f + i * .12f) + size.height * (.07f - i * .012f) *
                        (sin(x * f + ph) * .6f + sin(x * f * 2.3f + ph * 1.7f) * .3f + sin(x * f * 5.1f) * .1f)
                    lineTo(x, y); x += 8f
                }
                lineTo(size.width, size.height); close()
            }
            drawPath(p, c)
        }
    }
}

@Composable
fun BackdropLayer(b: Backdrop, modifier: Modifier = Modifier.fillMaxSize()) = when (b) {
    is Backdrop.Scene -> SceneCanvas(b.index, modifier)
    is Backdrop.Art -> Box(modifier) {
        Image(b.soft, null, Modifier.fillMaxSize().graphicsLayer { scaleX = 1.3f; scaleY = 1.3f },
            contentScale = ContentScale.Crop, filterQuality = FilterQuality.High)
        Box(Modifier.fillMaxSize().background(Color.Black.copy(.3f)))
    }
}

// ───────── Glass ─────────
/** Real glass: the same backdrop, blurred and aligned to screen coordinates inside the shape, plus a light tint and a fine bright edge. */
@Composable
fun GlassSurface(
    modifier: Modifier, shape: Shape, strength: Int,
    contentAlignment: Alignment = Alignment.TopStart, content: @Composable BoxScope.() -> Unit
) {
    val backdrop = LocalBackdrop.current
    val cfg = LocalConfiguration.current
    var pos by remember { mutableStateOf(IntOffset.Zero) }
    val blurOk = Build.VERSION.SDK_INT >= 31       // RenderEffect needs Android 12+
    val tint = listOf(.05f, .11f, .19f)[strength.coerceIn(0, 2)] + if (blurOk) 0f else .09f
    Box(
        modifier
            .shadow(36.dp, shape, ambientColor = Color.Black.copy(.2f), spotColor = Color.Black.copy(.45f))
            .clip(shape)
            .onGloballyPositioned { pos = it.positionInRoot().round() },
        contentAlignment = contentAlignment
    ) {
        Box(Modifier.matchParentSize()) {
            Box(Modifier.requiredSize(cfg.screenWidthDp.dp, cfg.screenHeightDp.dp)
                .offset { IntOffset(-pos.x, -pos.y) }
                .then(if (blurOk) Modifier.blur(30.dp) else Modifier)) { BackdropLayer(backdrop) }
        }
        Box(Modifier.matchParentSize().background(Brush.verticalGradient(listOf(Color.White.copy(tint + .04f), Color.White.copy(tint * .6f)))))
        Box(Modifier.matchParentSize().border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(.5f), Color.White.copy(.06f), Color.White.copy(.16f))), shape))
        content()
    }
}

// ───────── One focus treatment for everything ─────────
@OptIn(ExperimentalFoundationApi::class)
fun Modifier.tvFocusable(
    shape: Shape, scaleTo: Float = 1.06f, fill: Boolean = false,
    onLongClick: (() -> Unit)? = null, onClick: () -> Unit
): Modifier = composed {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) scaleTo else 1f, spring(.75f, 380f), label = "scale")
    val a by animateFloatAsState(if (focused) 1f else 0f, tween(200), label = "ring")
    val lift by animateDpAsState(if (focused) 20.dp else 0.dp, tween(260), label = "lift")
    this.graphicsLayer { scaleX = scale; scaleY = scale }
        .shadow(lift, shape, ambientColor = Color.Black.copy(.3f), spotColor = Color.Black.copy(.5f))
        .onFocusChanged { focused = it.isFocused }
        .clip(shape)
        .combinedClickable(onLongClick = onLongClick, onClick = onClick)
        .then(if (fill) Modifier.background(Color.White.copy(a * .14f)) else Modifier)
        .border(2.dp, SoftWhite.copy(a * .92f), shape)
}

// ───────── Shared components ─────────
val TileShape = RoundedCornerShape(16.dp)

@Composable
fun ArtTile(app: AppEntry, w: Dp, h: Dp, modifier: Modifier = Modifier, onLongClick: (() -> Unit)? = null, onClick: () -> Unit) {
    Image(app.art, app.label, modifier.size(w, h).tvFocusable(TileShape, 1.08f, onLongClick = onLongClick, onClick = onClick),
        contentScale = ContentScale.Crop)
}

@Composable
fun GlassCircleButton(icon: ImageVector, glass: Int, size: Dp = 56.dp, onClick: () -> Unit) =
    GlassSurface(Modifier.size(size).tvFocusable(CircleShape, 1.1f, onClick = onClick), CircleShape, glass, Alignment.Center) {
        Icon(icon, null, Modifier.size(size * .45f), tint = SoftWhite)
    }

@Composable
fun Pill(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(24.dp)
    Box(modifier.height(48.dp).tvFocusable(shape, 1.04f, fill = true, onClick = onClick)
        .background(Color.White.copy(if (selected) .22f else .06f)).padding(horizontal = 20.dp), Alignment.Center) {
        Text(text, style = T.label)
    }
}

@Composable
fun QuietEmpty(icon: ImageVector, title: String, hint: String) = Row(
    Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically
) {
    Icon(icon, null, Modifier.size(32.dp), tint = SoftWhite.copy(.5f))
    Spacer(Modifier.width(16.dp))
    Column { Text(title, style = T.title.copy(color = SoftWhite.copy(.85f))); Text(hint, style = T.body) }
}
