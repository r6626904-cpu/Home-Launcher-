package com.personaltv.home

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import org.json.JSONObject
import java.net.URL

/** Real TV artwork: the app's own leanback banner (16:9). Icon-on-brand-colour fallback if none. */
class AppEntry(val pkg: String, val label: String, val intent: Intent, val art: ImageBitmap)

data class Weather(val temp: Int, val code: Int) {
    val text get() = when (code) {
        0 -> "Clear"; 1, 2 -> "Mostly clear"; 3 -> "Cloudy"; 45, 48 -> "Fog"
        in 51..67, in 80..82 -> "Rain"; in 71..77, 85, 86 -> "Snow"; in 95..99 -> "Storm"; else -> "Fair"
    }
}

private val preferred = listOf(
    "com.google.android.youtube.tv", "com.netflix.ninja", "com.amazon.amazonvideo.livingroom",
    "com.spotify.tv.android", "com.google.android.youtube.tvmusic", "com.plexapp.android", "com.disney.disneyplus"
)

fun loadApps(ctx: Context): List<AppEntry> {
    val pm = ctx.packageManager
    val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
    val seen = HashSet<String>()
    return pm.queryIntentActivities(query, 0).mapNotNull { ri ->
        val ai = ri.activityInfo
        if (ai.packageName == ctx.packageName || !seen.add(ai.packageName)) return@mapNotNull null
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
            .setComponent(ComponentName(ai.packageName, ai.name))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        AppEntry(ai.packageName, ri.loadLabel(pm).toString(), intent, artFor(pm, ai))
    }.sortedBy { it.label.lowercase() }
}

private fun artFor(pm: PackageManager, ai: ActivityInfo): ImageBitmap {
    val banner = ai.loadBanner(pm) ?: ai.applicationInfo.loadBanner(pm)
    if (banner != null) return banner.toBitmap(320, 180).asImageBitmap()
    val icon = ai.loadIcon(pm).toBitmap(112, 112)
    val px = Bitmap.createScaledBitmap(icon, 1, 1, true).getPixel(0, 0)
    val c = android.graphics.Color
    val bg = c.rgb((c.red(px) * .55).toInt(), (c.green(px) * .55).toInt(), (c.blue(px) * .55).toInt())
    val out = Bitmap.createBitmap(320, 180, Bitmap.Config.ARGB_8888)
    Canvas(out).apply { drawColor(bg); drawBitmap(icon, 104f, 34f, null) }
    return out.asImageBitmap()
}

/** Open-Meteo: no API key. Change the default coordinates (or wire up a location source). */
fun fetchWeather(lat: Double, lon: Double): Weather? = runCatching {
    val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code&timezone=auto"
    val cur = JSONObject(URL(url).readText()).getJSONObject("current")
    Weather(Math.round(cur.getDouble("temperature_2m")).toInt(), cur.getInt("weather_code"))
}.getOrNull()

class HomeState(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("ptv", Context.MODE_PRIVATE)
    var apps by mutableStateOf(emptyList<AppEntry>())
    var weather by mutableStateOf<Weather?>(null)
    var reload by mutableIntStateOf(0)
    var pinned by mutableStateOf(prefs.getString("pinned", "")!!.split(",").filter { it.isNotBlank() })
        private set
    var scene by mutableIntStateOf(prefs.getInt("scene", 0)); private set
    var glass by mutableIntStateOf(prefs.getInt("glass", 1)); private set
    var musicBackdrop by mutableStateOf(prefs.getBoolean("musicBg", true)); private set
    var saved by mutableStateOf(prefs.getString("saved", "")!!.split("|").filter { it.isNotBlank() })
    val collections = emptyList<String>()
    val lat get() = prefs.getFloat("lat", 28.61f).toDouble()
    val lon get() = prefs.getFloat("lon", 77.21f).toDouble()

    val favorites: List<AppEntry> get() {
        if (pinned.isNotEmpty()) return pinned.mapNotNull { p -> apps.find { it.pkg == p } }
        val pref = preferred.mapNotNull { p -> apps.find { it.pkg == p } }
        return (pref + apps.filter { it !in pref }).take(10)
    }
    fun isPinned(a: AppEntry) = favorites.any { it.pkg == a.pkg }
    fun togglePin(a: AppEntry) {
        val cur = favorites.map { it.pkg }
        pinned = if (a.pkg in cur) cur - a.pkg else cur + a.pkg
        prefs.edit().putString("pinned", pinned.joinToString(",")).apply()
    }
    fun setScene(i: Int) { scene = i; prefs.edit().putInt("scene", i).apply() }
    fun setGlass(i: Int) { glass = i; prefs.edit().putInt("glass", i).apply() }
    fun setMusicBackdrop(b: Boolean) { musicBackdrop = b; prefs.edit().putBoolean("musicBg", b).apply() }
}
