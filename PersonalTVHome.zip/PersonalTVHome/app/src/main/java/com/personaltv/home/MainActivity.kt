package com.personaltv.home

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val state = HomeState(applicationContext)
        setContent { PersonalTvTheme { Root(state) } }
    }
    override fun onResume() { super.onResume(); MediaWatcher.start(applicationContext) }
}
