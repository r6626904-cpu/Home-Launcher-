package com.personaltv.home

import android.content.*
import android.net.Uri
import android.os.SystemClock
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Icon
import androidx.tv.material3.Text
import kotlinx.coroutines.*
import java.util.Date

enum class Screen { Home, Apps, MySpace }
enum class Panel { Main, Wallpapers, Appearance }

@Composable
fun Root(s: HomeState) {
    val ctx = LocalContext.current
    val now by MediaWatcher.now.collectAsState()
    var screen by remember { mutableStateOf(Screen.Home) }
    var panelOpen by remember { mutableStateOf(false) }
    var panel by remember { mutableStateOf(Panel.Main) }

    LaunchedEffect(s.reload) { s.apps = withContext(Dispatchers.IO) { loadApps(ctx) } }
    LaunchedEffect(Unit) { while (true) { withContext(Dispatchers.IO) { fetchWeather(s.lat, s.lon) }?.let { s.weather = it }; delay(30 * 60_000L) } }
    DisposableEffect(Unit) {
        val r = object : BroadcastReceiver() { override fun onReceive(c: Context?, i: Intent?) { s.reload++ } }
        ctx.registerReceiver(r, IntentFilter().apply { addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED); addDataScheme("package") })
        onDispose { ctx.unregisterReceiver(r) }
    }

    val soft = now?.soft
    val backdrop = remember(soft, s.scene, s.musicBackdrop) {
        if (soft != null && s.musicBackdrop) Backdrop.Art(soft.asImageBitmap()) else Backdrop.Scene(s.scene)
    }
    fun launch(i: Intent) = runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    fun go(to: Screen) { screen = to; panelOpen = false; panel = Panel.Main }

    BackHandler(panelOpen) { if (panel != Panel.Main) panel = Panel.Main else panelOpen = false }
    BackHandler(!panelOpen && screen != Screen.Home) { screen = Screen.Home }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Crossfade(backdrop, animationSpec = tween(900), label = "bg") { BackdropLayer(it) }
        val extra by animateFloatAsState(if (screen == Screen.Home) 0f else .3f, tween(500), label = "scrim")
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
            0f to Color.Black.copy(.28f + extra), .25f to Color.Black.copy(extra), .7f to Color.Black.copy(extra), 1f to Color.Black.copy(.22f + extra))))

        CompositionLocalProvider(LocalBackdrop provides backdrop) {
            AnimatedContent(screen, transitionSpec = {
                (fadeIn(tween(420)) + scaleIn(tween(420), .98f)) togetherWith fadeOut(tween(240))
            }, label = "screen") { sc ->
                when (sc) {
                    Screen.Home -> HomeScreen(s, now, !panelOpen, { panelOpen = true }, { go(Screen.Apps) }) { launch(it.intent) }
                    Screen.Apps -> AppsScreen(s) { launch(it.intent) }
                    Screen.MySpace -> MySpaceScreen(s) { go(Screen.Home) }
                }
            }
            AnimatedVisibility(panelOpen, Modifier.fillMaxSize(),
                enter = slideInHorizontally(tween(450)) { it / 2 } + fadeIn(tween(350)),
                exit = slideOutHorizontally(tween(300)) { it / 2 } + fadeOut(tween(250))) {
                SettingsPanel(s, panel, { panel = it }, ::go,
                    system = { launch(Intent(Settings.ACTION_SETTINGS)) },
                    discover = { ctx.packageManager.getLeanbackLaunchIntentForPackage("com.google.android.apps.tv.launcherx")?.let { launch(it) } },
                    search = { if (launch(Intent(Intent.ACTION_ASSIST)).isFailure) launch(Intent(Intent.ACTION_WEB_SEARCH)) },
                    musicAccess = { launch(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) })
            }
        }
    }
}

// ───────── Home ─────────
@Composable
fun HomeScreen(s: HomeState, now: NowPlaying?, focusDock: Boolean, onSettings: () -> Unit, onAllApps: () -> Unit, launch: (AppEntry) -> Unit) {
    Box(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 64.dp, vertical = 40.dp), verticalAlignment = Alignment.CenterVertically) {
            WeatherBlock(s.weather)
            Spacer(Modifier.weight(1f))
            Clock()
            Spacer(Modifier.width(28.dp))
            GlassCircleButton(Icons.Rounded.Settings, s.glass, onClick = onSettings)
        }
        Column(Modifier.align(Alignment.BottomCenter).padding(horizontal = 64.dp).padding(bottom = 56.dp), verticalArrangement = Arrangement.spacedBy(24.dp)) {
            now?.let { NowPlayingCard(it, s.glass) }
            Dock(s, focusDock, onAllApps, launch)
        }
    }
}

@Composable
fun Dock(s: HomeState, focusDock: Boolean, onAllApps: () -> Unit, launch: (AppEntry) -> Unit) {
    val favs = s.favorites
    val fr = remember { FocusRequester() }
    LaunchedEffect(favs.firstOrNull()?.pkg, focusDock) { if (focusDock && favs.isNotEmpty()) { delay(250); runCatching { fr.requestFocus() } } }
    GlassSurface(Modifier.fillMaxWidth(), RoundedCornerShape(40.dp), s.glass) {
        LazyRow(contentPadding = PaddingValues(18.dp), horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
            items(favs, key = { it.pkg }) { a ->
                ArtTile(a, 144.dp, 84.dp, if (a === favs.first()) Modifier.focusRequester(fr) else Modifier) { launch(a) }
            }
            item {
                Box(Modifier.size(84.dp).tvFocusable(TileShape, 1.08f, onClick = onAllApps).background(Color.White.copy(.14f)), Alignment.Center) {
                    Icon(Icons.Rounded.Apps, "All apps", Modifier.size(36.dp), tint = SoftWhite)
                }
            }
        }
    }
}

@Composable
fun WeatherBlock(w: Weather?) {
    if (w == null) return
    val icon = when (w.code) { 0, 1, 2 -> Icons.Rounded.WbSunny; in 51..67, in 80..82 -> Icons.Rounded.WaterDrop
        in 71..77 -> Icons.Rounded.AcUnit; in 95..99 -> Icons.Rounded.Bolt; else -> Icons.Rounded.Cloud }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, Modifier.size(30.dp), tint = SoftWhite)
        Spacer(Modifier.width(12.dp)); Text("${w.temp}°", style = T.weather)
        Spacer(Modifier.width(12.dp)); Text(w.text, style = T.body)
    }
}

@Composable
fun Clock() {
    val ctx = LocalContext.current
    val fmt = remember { android.text.format.DateFormat.getTimeFormat(ctx) }
    var t by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { t = Date(); delay(60_000L - System.currentTimeMillis() % 60_000L + 50) } }
    Text(fmt.format(t), style = T.clock)
}

// ───────── Music ─────────
@Composable
fun NowPlayingCard(np: NowPlaying, glass: Int) {
    var progress by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(np.controller, np.durationMs) {
        while (true) {
            val st = np.controller.playbackState
            if (st != null && np.durationMs > 0) {
                val el = if (st.state == android.media.session.PlaybackState.STATE_PLAYING) (SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed else 0f
                progress = ((st.position + el) / np.durationMs).coerceIn(0f, 1f)
            }
            delay(500)
        }
    }
    val tc = np.controller.transportControls
    GlassSurface(Modifier.widthIn(max = 620.dp), RoundedCornerShape(32.dp), glass) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            np.art?.let { Image(it.asImageBitmap(), null, Modifier.size(112.dp).clip(RoundedCornerShape(20.dp)), contentScale = ContentScale.Crop) }
            Spacer(Modifier.width(20.dp))
            Column(Modifier.weight(1f)) {
                Text(np.title, style = T.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(np.artist, style = T.body, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(12.dp))
                Box(Modifier.fillMaxWidth().height(4.dp).clip(CircleShape).background(Color.White.copy(.2f))) {
                    Box(Modifier.fillMaxWidth(progress).fillMaxHeight().background(SoftWhite))
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    GlassCircleButton(Icons.Rounded.SkipPrevious, glass, 48.dp) { tc.skipToPrevious() }
                    GlassCircleButton(if (np.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, glass, 48.dp) { if (np.playing) tc.pause() else tc.play() }
                    GlassCircleButton(Icons.Rounded.SkipNext, glass, 48.dp) { tc.skipToNext() }
                }
            }
        }
    }
}

// ───────── Apps ─────────
@Composable
fun AppsScreen(s: HomeState, launch: (AppEntry) -> Unit) {
    Column(Modifier.fillMaxSize().padding(top = 48.dp)) {
        Column(Modifier.padding(horizontal = 64.dp)) {
            Text("Apps", style = T.display)
            Text("Hold OK on an app to pin it to Home, or unpin it.", style = T.body)
        }
        Spacer(Modifier.height(28.dp))
        LazyVerticalGrid(GridCells.Adaptive(208.dp), contentPadding = PaddingValues(horizontal = 64.dp, vertical = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(28.dp), verticalArrangement = Arrangement.spacedBy(32.dp)) {
            items(s.apps, key = { it.pkg }) { a ->
                Column {
                    ArtTile(a, 208.dp, 117.dp, onLongClick = { s.togglePin(a) }) { launch(a) }
                    Spacer(Modifier.height(12.dp))
                    Text(a.label, style = T.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (s.isPinned(a)) Text("On Home", style = T.body.copy(fontSize = 14.sp))
                }
            }
        }
    }
}

// ───────── My Space ─────────
@Composable
fun MySpaceScreen(s: HomeState, goHome: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 64.dp, vertical = 48.dp), verticalArrangement = Arrangement.spacedBy(36.dp)) {
        Text("My Space", style = T.display)
        Section("Saved titles") {
            if (s.saved.isEmpty()) QuietEmpty(Icons.Rounded.Bookmark, "Nothing saved yet", "Titles you save will wait here.")
            else LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                items(s.saved) { t ->
                    GlassSurface(Modifier.size(208.dp, 117.dp).tvFocusable(TileShape, 1.06f) {}, TileShape, s.glass, Alignment.BottomStart) {
                        Text(t, style = T.label, modifier = Modifier.padding(16.dp), maxLines = 2)
                    }
                }
            }
        }
        Section("Collections") {
            if (s.collections.isEmpty()) QuietEmpty(Icons.Rounded.Collections, "No collections", "Group titles into collections to find them faster.")
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) { Text(title, style = T.title); content() }
}

// ───────── Settings side panel ─────────
@Composable
fun SettingsPanel(
    s: HomeState, panel: Panel, setPanel: (Panel) -> Unit, go: (Screen) -> Unit,
    system: () -> Unit, discover: () -> Unit, search: () -> Unit, musicAccess: () -> Unit
) {
    Box(Modifier.fillMaxSize().padding(28.dp), Alignment.CenterEnd) {
        GlassSurface(Modifier.width(460.dp).fillMaxHeight(), RoundedCornerShape(36.dp), s.glass) {
            AnimatedContent(panel, transitionSpec = { fadeIn(tween(300)) togetherWith fadeOut(tween(160)) }, label = "panel") { p ->
                val fr = remember { FocusRequester() }
                LaunchedEffect(p) { delay(200); runCatching { fr.requestFocus() } }
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(24.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    when (p) {
                        Panel.Main -> {
                            item { Text("Settings", style = T.display.copy(fontSize = 30.sp), modifier = Modifier.padding(bottom = 12.dp)) }
                            item { Row2(Icons.Rounded.Cast, "Chromecast settings", "Network, display, accounts, system", Modifier.focusRequester(fr), system) }
                            item { Label("Go to") }
                            item { Row2(Icons.Rounded.Home, "Home") { go(Screen.Home) } }
                            item { Row2(Icons.Rounded.Explore, "Discover", onClick = discover) }
                            item { Row2(Icons.Rounded.Bookmarks, "My Space") { go(Screen.MySpace) } }
                            item { Row2(Icons.Rounded.Apps, "Apps") { go(Screen.Apps) } }
                            item { Row2(Icons.Rounded.Search, "Search", onClick = search) }
                            item { Label("Personalise") }
                            item { Row2(Icons.Rounded.Image, "Wallpapers") { setPanel(Panel.Wallpapers) } }
                            item { Row2(Icons.Rounded.Palette, "Appearance") { setPanel(Panel.Appearance) } }
                            item { Row2(Icons.Rounded.MusicNote, "Music backdrop access", "Allow notification access to show album art", onClick = musicAccess) }
                        }
                        Panel.Wallpapers -> {
                            item { Row2(Icons.Rounded.ChevronLeft, "Wallpapers", modifier = Modifier.focusRequester(fr)) { setPanel(Panel.Main) } }
                            items(SceneNames.indices.toList()) { i ->
                                Box(Modifier.fillMaxWidth().height(112.dp).tvFocusable(RoundedCornerShape(24.dp), 1.03f) { s.setScene(i) }) {
                                    SceneCanvas(i, Modifier.fillMaxSize())
                                    Text(SceneNames[i], style = T.label, modifier = Modifier.align(Alignment.BottomStart).padding(16.dp))
                                    if (s.scene == i) Icon(Icons.Rounded.Check, null, Modifier.align(Alignment.TopEnd).padding(14.dp).size(24.dp), tint = SoftWhite)
                                }
                            }
                        }
                        Panel.Appearance -> {
                            item { Row2(Icons.Rounded.ChevronLeft, "Appearance", modifier = Modifier.focusRequester(fr)) { setPanel(Panel.Main) } }
                            item { Label("Glass") }
                            item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                listOf("Clear", "Balanced", "Frosted").forEachIndexed { i, n -> Pill(n, s.glass == i, { s.setGlass(i) }) }
                            } }
                            item { Label("Music backdrop") }
                            item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Pill("Album art", s.musicBackdrop, { s.setMusicBackdrop(true) }); Pill("Wallpaper", !s.musicBackdrop, { s.setMusicBackdrop(false) })
                            } }
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun Label(t: String) = Text(t, style = T.body.copy(fontSize = 15.sp), modifier = Modifier.padding(top = 16.dp, bottom = 4.dp, start = 8.dp))

@Composable
private fun Row2(icon: ImageVector, title: String, subtitle: String? = null, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Row(modifier.fillMaxWidth().heightIn(min = 68.dp).tvFocusable(RoundedCornerShape(20.dp), 1.02f, fill = true, onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, Modifier.size(28.dp), tint = SoftWhite)
        Spacer(Modifier.width(16.dp))
        Column { Text(title, style = T.title.copy(fontWeight = androidx.compose.ui.text.font.FontWeight.Medium)); subtitle?.let { Text(it, style = T.body.copy(fontSize = 15.sp)) } }
    }
}
