package com.personaltv.home

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService
import kotlinx.coroutines.flow.MutableStateFlow

/** Empty on purpose: enabling notification access for this service lets us read active media sessions. */
class MediaListener : NotificationListenerService()

class NowPlaying(
    val title: String, val artist: String, val art: Bitmap?, val soft: Bitmap?,
    val playing: Boolean, val durationMs: Long, val controller: MediaController
)

object MediaWatcher {
    val now = MutableStateFlow<NowPlaying?>(null)
    private var started = false
    private var current: MediaController? = null
    private var lastArt: Bitmap? = null
    private var lastSoft: Bitmap? = null

    private val cb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = publish()
        override fun onPlaybackStateChanged(state: PlaybackState?) = publish()
        override fun onSessionDestroyed() { current = null; now.value = null }
    }

    fun start(ctx: Context) {
        if (started) return
        started = true
        val msm = ctx.getSystemService(MediaSessionManager::class.java)
        val cn = ComponentName(ctx, MediaListener::class.java)
        try {
            msm.addOnActiveSessionsChangedListener({ pick(it.orEmpty()) }, cn)
            pick(msm.getActiveSessions(cn))
        } catch (_: SecurityException) { started = false } // notification access not granted yet
    }

    private fun isMusic(c: MediaController): Boolean {
        val st = c.playbackState?.state
        val live = st == PlaybackState.STATE_PLAYING || st == PlaybackState.STATE_PAUSED || st == PlaybackState.STATE_BUFFERING
        val md = c.metadata ?: return false
        return live && (!md.getString(MediaMetadata.METADATA_KEY_ARTIST).isNullOrBlank() ||
            !md.getString(MediaMetadata.METADATA_KEY_ALBUM).isNullOrBlank())
    }

    private fun pick(list: List<MediaController>) {
        val music = list.filter { isMusic(it) }
        val c = music.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: music.firstOrNull()
        if (c?.sessionToken != current?.sessionToken) {
            current?.unregisterCallback(cb); current = c; c?.registerCallback(cb)
        }
        publish()
    }

    private fun publish() {
        val c = current ?: run { now.value = null; return }
        val md = c.metadata
        if (md == null || !isMusic(c)) { now.value = null; return }
        val art = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
        if (art !== lastArt) {  // tiny upscaled bitmap = cheap, buttery blur on every Android version
            lastArt = art; lastSoft = art?.let { Bitmap.createScaledBitmap(it, 24, 24, true) }
        }
        now.value = NowPlaying(
            md.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Unknown",
            md.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "",
            art, lastSoft, c.playbackState?.state == PlaybackState.STATE_PLAYING,
            md.getLong(MediaMetadata.METADATA_KEY_DURATION), c
        )
    }
}
