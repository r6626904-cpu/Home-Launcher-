# Personal TV Home — "Scenic Glass"
1. Drop Inter .ttf files into app/src/main/res/font (inter_regular / inter_medium / inter_semibold).
2. Open in Android Studio, build, `adb install` to the TV.
3. Press Home on the TV and choose Personal TV Home (Always).
4. Music backdrop: Settings > Music backdrop access > enable Personal TV Home.
5. Weather uses Open-Meteo; set coordinates via prefs "lat"/"lon" (default New Delhi).
